//
//  main.m
//  3变量的作用域
//
//  Created by zhengwei on 1/24/16.
//  Copyright © 2016 zhengwei. All rights reserved.
//
// 1 内部变量会将外部变量覆盖掉
// 2 内部变量：方法体
// 3 “外部变量”：除了内部变量屏蔽之外的部分
// 4 外部变量：

#import <Foundation/Foundation.h>
int a = 3;
int main(int argc, const char * argv[]) {
    NSLog(@"a3=%d",a);
    int a = 2;
    NSLog(@"a2=%d",a);
    @autoreleasepool {
//      1 作用域
        int a = 1;
        NSLog(@"a1=%d",a);
    }
    NSLog(@"a4=%d",a);
    return 0;
}
