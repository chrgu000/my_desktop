//
//  main.m
//  1HelloWorld
//
//  Created by zhengwei on 1/22/16.
//  Copyright © 2016 zhengwei. All rights reserved.
// Xcode
// CMD+B Build CMD+R = Build 单行：Run CMD+/
//模拟器
// CMD＋12345
// CMD＋shift＋H ：Home
// CMD＋L:Lock
// 多行
/*
 dfsfjiosfs
 fsfsfs
 */
// 打开意境存在的工程：1 文件 2 xcode
// 文件类型：.m .h  m：oc c 内容实现  h：方法介绍
// 文件体：头 内容
// cmd＋／
#import <Foundation/Foundation.h>// #import:引入一个文件
// 为什么？
// xocde7:头文件的使用

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        
        
        // insert code here...
//      会车 字符串＝@“” ＋内容
        NSLog(@"hello world!");
        NSLog(@"Hello, World!");
        NSLog(@"你好 oc");
    }
    return 0;
}
// 补充：
//<系统lib> "自定义"







