//
//  main.m
//  4运算符
//
//  Created by zhengwei on 1/24/16.
//  Copyright © 2016 zhengwei. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        /*
//      1 算数运算符
        int a = 2;
        int b = 3;
        NSLog(@"%d",a+b*a-b/a);// 2+6-1 = 7
//      先算乘除 后算加减。除法：数据类型转化
//      有括号：先算括号
        NSLog(@"%d",(a+b)*a-b/a);// 5*2-1 ＝ 9
//        NSLog(@"%d",-a+b);
        NSLog(@"%d",b/(-a)); // -1.5->int -1
//        NSLog(@"%d",b*a);
//        NSLog(@"%d",b/a);// / int／int ＝ int
//      float－》int    1.5 － 》int ＝ 1
        
        NSLog(@"Hello, World!");
         
//      2 关系运算符 > < == !=
//      优先级：关系运算符<算数运算符
//      关系成立－》true 假
        BOOL a = 3 > 2;
        NSLog(@"a=%d",a);
        BOOL b = 3 < 2;
        BOOL c = 3 == 2;
        BOOL d = 3 != 2;
        NSLog(@"a=%d b=%d c=%d d=%d",a,b,c,d);
        
        int e = 3+a>1;//3+1>1 = ?1  4>1
        NSLog(@"e1=%d",e);
        int e2 = 3+a<1;//3+1<1 = ?1  4<1
        NSLog(@"e2=%d",e2);
        
        int e3 = 3+(a<1); // 3+(1<1)=3+0 = 3
        NSLog(@"e3=%d",e3);
         
//      3 取摸运算
        int a = 3;
        int b = 2;
        float c = 2.0;
        NSLog(@"a/b=%d",a/b);// 取整
        NSLog(@"a/c=%f",a/c);
        // 取余
        NSLog(@"%d",a%b); // 3-2  = 1
        NSLog(@"%d",9%4); // 9 -4 -4 = 1
         
//      4 赋值运算
        int a = 3;
        a -= 1;// a = 3-1  :  a=a-1;
        NSLog(@"a1=%d",a);
        
        a += 1; // a = a +1 = 3
        NSLog(@"a2=%d",a);
        a *= 2; // a = a*2 = 6
        NSLog(@"a3=%d",a);
        a /= 3; // a = a/3 = 2
        NSLog(@"a4=%d",a);
         
//      5 自增自减员算符
        int a = 3;
        NSLog(@"%d",a--);// 3 a = a-1; a = 2;先执行nslog（a）
//      a = a-1
//        NSLog(@"a1=%d",a);
//      a = 2   --a :  a = a-1
//      1 a = a -1 => 1
//      2 nslog(a)
        NSLog(@"%d",--a);
//      a = 1
        NSLog(@"%d",a++);// a = a +1
//      a = 2
//      a = a+1
//      nslog(a)
        NSLog(@"%d",++a);
        
//      a-- --a
//      a--
//      1 nslog(a) 2 a = a-1
//      --a
//      1 a = a - 1 2 nslog(a)
         
//      6 位运算符
        int a = 5;
        int b = a & 0x03;// 与 ： 必须转化为2进制  只有两个位都为1那么才为1
        NSLog(@"b=%d",b);
         
        int a = 5;
        int b = a | 0x03;// 或 ： 必须转化为2进制  如果有一个位都为1那么才为1
        NSLog(@"b=%d",b);
         
        int a = 5;
        int b = a<<1;//数据整体左移动一位
        int c = a>>1;
        NSLog(@"a=%d b=%d c=%d",a,b,c);
         */
//      7 三目运算符
        int a = (5<3)?2:0;
        NSLog(@"a=%d",a);
        
    }
    return 0;
}
