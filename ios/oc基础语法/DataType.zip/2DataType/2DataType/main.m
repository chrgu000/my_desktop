//
//  main.m
//  2DataType
//
//  Created by zhengwei on 1/23/16.
//  Copyright © 2016 zhengwei. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        /*
        // 1 数据类型：
        int a = 1;
        float b = 2.5;
        BOOL c = false;// 真：true：1 假：false：0
        BOOL d = YES;
//      有参数 无参数NSLOG
        NSLog(@"a=%d",a); //参数1 ： 表明需要输出的数据类型 参数2:当前需要输出的数据
        NSLog(@"b=%f",b);
        NSLog(@"c=%d",c);
        NSLog(@"d=%d",d);
        NSLog(@"Hello, World!");//NSlog(打印的内容)
        char e = 'e';
        double f = 2.1e-10;
//      3 NSLOG
        NSLog(@"%c %g",e,f);
//      所有的对象声明 ＊  %@
        NSString *myString = @"hello world!";
        NSLog(@"%@",myString);
//      id 表示任意oc对象
        id mString = @"my id = Hello world!";
        NSLog(@"mString=%@",mString);
         
//      2 限定词: 大数据 特定的数据类型上
//      黄色 警告 红色 错误信息
        int a = 123456789012345;
        long long int b = 123456789012345;
        NSLog(@"a= %d b = %lld",a,b);
        
        unsigned c = 1;
        unsigned d = -1;
        NSLog(@"%d %d",c,d);
        NSLog(@"%u %u",c,d);
         */
//      3 数据类型的转化
        float a = 1.5;
        int b = (int)a;
        NSLog(@"a=%f b=%d",a,b);
        int c = 2;
        float d = (float)c;
        NSLog(@"c=%d d=%f",c,d);
        
    }
    return 0;
}
