//app.js
App({
  onLaunch: function () {

  },
  onError: function(err){

    console.log(err);
  }
})